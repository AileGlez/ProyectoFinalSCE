cd ~/Desktop/ce/SimpleRMIAutonomoUbuntu
